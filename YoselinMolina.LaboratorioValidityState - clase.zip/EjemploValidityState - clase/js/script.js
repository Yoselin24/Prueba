
function checkValidity (){
    var input = document.createElement('input');
    return ('validity' in input);
};

console.log(checkValidity());

function checkAllValidity () {
    var input = document.createElement('input');
    return ('validity' in input && 'badInput' in input.validity && 'patternMismatch' in input.validity && 'rangeOverflow' in input.validity && 'rangeUnderflow' in input.validity && 'stepMismatch' in input.validity && 'tooLong' in input.validity && 'tooShort' in input.validity && 'typeMismatch' in input.validity && 'valid' in input.validity && 'valueMissing' in input.validity);
};

console.log(checkAllValidity());


// quitar el validar automatico 
var forms = document.querySelectorAll('.validate');
for (var i = 0; i < forms.length; i++) {
    forms[i].setAttribute('novalidate', true);
}


// validacion de campos
var hasError = function (field) {

    // no validar ni campos de archivo, reset, submit y button
    if (field.disabled || field.type === 'file' || field.type === 'reset' || field.type === 'submit' || field.type === 'button') return;

    // obtener validador
    var validity = field.validity;

    console.log(validity);


    // si es valido, retorne
    if (validity.valid) return;

    // si el campo es requerido
    if (validity.valueMissing) return 'Por favor debe de rellenar el campo';

    // Si no es del tipo apropiado
    if (validity.typeMismatch) {

        // Email
        if (field.type === 'email') return 'Ingrese un correo electronico valido.';

        // URL
        if (field.type === 'url') return 'Ingrese un URL válido.';

    }

    // Si es muy corto
    if (validity.tooShort) return 'El campo debe estar entre ' + field.getAttribute('minLength') + ' caracteres o más. Actualmente usted tiene  ' + field.value.length + ' caracteres.';

    // Si es muy largo
    if (validity.tooLong) return 'El texto debe ser menor que ' + field.getAttribute('maxLength') + ' caracteres. Usted ha ingresado ' + field.value.length + ' caracteres.';

    // si la entrada no es un número
    if (validity.badInput) return 'Por favor ingrese un número.';

    // si el numero no esta un intervalo valido
    if (validity.stepMismatch) return 'Seleccione un invervalo válido.';

    // Si el numero sobrepaso el maximo
    if (validity.rangeOverflow) return 'Seleccione un valor que sea menor que ' + field.getAttribute('max') + '.';

    // Si el numero esta por debajo del minimo
    if (validity.rangeUnderflow) return 'Seleccione un valor que sea mayor que ' + field.getAttribute('min') + '.';
  
      // Si el patron no funciona
    if (validity.patternMismatch) {

        // Si el patron viene incluido
        if (field.hasAttribute('title')) return field.getAttribute('title');

        // De otra forma
        return 'Por favor, utilice el formato requerido.';

    }

    // si todo lo demás falla, despliegue lo siguiente
    return 'El valor ingresado en el campo es invalido.';

};


// Muestra el mensaje de error pesonalizado
var showError = function (field, error) {

    // Agrega la clase error del css al campo
    field.classList.add('error');
  
    // Si el campo es un radio button, muestre un mensaje de error para todos y obtenga el ultimo campo
    if (field.type === 'radio' && field.name) {
        var group = document.getElementsByName(field.name);
        if (group.length > 0) {
            for (var i = 0; i < group.length; i++) {
                // solo verifique los campos de este formulario
                if (group[i].form !== field.form) continue;
                group[i].classList.add('error');
            }
            field = group[group.length - 1];
        }
    }

    // Obtener id o nombre del campo
    var id = field.id || field.name;
    if (!id) return;

    // Verifique si el mensaje de error existe, sino cree uno.
    var message = field.form.querySelector('.error-message#error-for-' + id );
    if (!message) {
        message = document.createElement('div');
        message.className = 'error-message';
        message.id = 'error-for-' + id;
        
        // Si el campo es un radio o un checkbox, ponga el mensaje despues de ese componente
        var label;
        if (field.type === 'radio' || field.type ==='checkbox') {
            label = field.form.querySelector('label[for="' + id + '"]') || field.parentNode;
            if (label) {
                label.parentNode.insertBefore( message, label.nextSibling );
            }
        }

        // de otra forma insertelo despues del elemento
        if (!label) {
            field.parentNode.insertBefore( message, field.nextSibling );
        }

    }
    
    // Agregar atributo ARIA role al campo
    field.setAttribute('aria-describedby', 'error-for-' + id);

    // Actualice mensaje de error
    message.innerHTML = error;

    // Muestre mensaje de error
    message.style.display = 'block';
    message.style.visibility = 'visible';

};


// Remover mensaje de error
var removeError = function (field) {

    // Remover clase de error del campo
    field.classList.remove('error');
    
    // Remover etiqueta ARIA
    field.removeAttribute('aria-describedby');

    // Si el tipo de campo es un radio, remueva el error del ultimo campo del formulario que se agrego
    if (field.type === 'radio' && field.name) {
        var group = document.getElementsByName(field.name);
        if (group.length > 0) {
            for (var i = 0; i < group.length; i++) {
                // Only check fields in current form
                if (group[i].form !== field.form) continue;
                group[i].classList.remove('error');
            }
            field = group[group.length - 1];
        }
    }

    // obtiene el nombre o el id del campo
    var id = field.id || field.name;
    if (!id) return;
    

    // Chequea si quedaron mensajes de error en el formulario
    var message = field.form.querySelector('.error-message#error-for-' + id + '');
    if (!message) return;

    // Si es así, esconda todos los campos de mensaje de error y limpielos
    message.innerHTML = '';
    message.style.display = 'none';
    message.style.visibility = 'hidden';

};


// Crea un evento de tipo blur 
document.addEventListener('blur', function (event) {

    // Solo haga esto, si el formulario tiene un campo con la propiedad validate
    if (!event.target.form.classList.contains('validate')) return;

    // Valide el campo
    var error = hasError(event.target);
  
    // SI hay un error, muestrelo
    if (error) {
        showError(event.target, error);
        return;
    }

    // De otra forma, quite el error
    removeError(event.target);

}, true);


// Revise todos los campos en el Submit
document.addEventListener('submit', function (event) {

    // Solo verifique si el campo tiene la opcion validate
    if (!event.target.classList.contains('validate')) return;

    // Obtiene todos los formularios de la pagina. Si los hay
    var fields = event.target.elements;

    // Valida cada campo
    // verifique cada campo para mostrar los errores
    var error, hasErrors;
    for (var i = 0; i < fields.length; i++) {
        error = hasError(fields[i]);
        if (error) {
            showError(fields[i], error);
            if (!hasErrors) {
                hasErrors = fields[i];
            }
        }
    }

    // Si hay errores, no envie el formulario aún y ponga el foco en el primer elemento con error
    if (hasErrors) {
        event.preventDefault();
        hasErrors.focus();
    }

    // De otra manera envie el formulario

}, false);